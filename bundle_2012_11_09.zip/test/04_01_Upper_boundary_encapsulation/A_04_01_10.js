// Copyright 2012 Google Inc. All Rights Reserved.

var A_04_01_10 = {
    name:'A_04_01_10',
    assert:'Upper-boundary encapsulation: attributes of the shadow root object',
    link:'http://www.w3.org/TR/shadow-dom/#upper-boundary-encapsulation',
    highlight: 'The parentNode and parentElement attributes of the shadow root object ' +
    	'must always return null.'
};

test(function () {
    var d = document.implementation.createHTMLDocument('test doc');
    var s = new SR(d.body);
    assert_equals(s.parentNode, null, 'the parentNode attribute of the shadow ' +
        'root object must always return null');
}, 'A_04_01_10_T01', PROPS(A_04_01_10, {
    author:'Sergey G. Grekhov <sgrekhov@unipro.ru>',
    reviewer:''
}));

test(function () {
    var d = document.implementation.createHTMLDocument('test doc');
    var s = new SR(d.body);
    assert_equals(s.parentElement, null,
        'the parentElement attribute of the shadow root object ' +
            'must always return null');
}, 'A_04_01_10_T02', PROPS(A_04_01_10, {
    author:'Sergey G. Grekhov <sgrekhov@unipro.ru>',
    reviewer:''
}));
