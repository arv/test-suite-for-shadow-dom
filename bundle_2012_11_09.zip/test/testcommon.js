// Copyright 2012 Google Inc. All Rights Reserved.

"use strict";

function ShadowDomNotSupportedError() {
    this.message = "Shadow DOM is not supported";
}

function ShadowDomNotSupported() {
    throw new ShadowDomNotSupportedError();
}

// Alias the constructor so vendor-prefixed implementations can run
// most of the test suite.
var SR = window.ShadowRoot ||
    window.WebKitShadowRoot ||
    // Add other vendor prefixes here.
    ShadowDomNotSupported;


function PROPS(assertion, properties) {
    var res = Object(), attr;
    for (attr in assertion) {
        if (assertion.hasOwnProperty(attr)) {
            res[attr] = assertion[attr];
        }
    }
    for (attr in properties) {
        if (properties.hasOwnProperty(attr)) {
            res[attr] = properties[attr];
        }
    }
    return res;

}

function rethrowInternalErrors(e) {
    if (e instanceof ShadowDomNotSupportedError) {
        throw e;
    }

}

function newDocument() {
    return document.implementation.createDocument();
}

function newHTMLDocument() {
    return document.implementation.createHTMLDocument();
}

function newIFrame(ctx) {
    var iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    iframe.style.visibility = 'hidden';
    document.body.appendChild(iframe);

    if (typeof(ctx) == "undefined" || typeof (ctx.iframes) != "object") {
        assert_unreached("Illegal context object in newIFrame");
    }
    ctx.iframes.push(iframe);

    assert_true(typeof(iframe.contentWindow) != "undefined"
        && typeof(iframe.contentWindow.document) != "undefined"
        && iframe.contentWindow.document != document, "Failed to create new rendered document"
    );
    return iframe;
}
function newRenderedHTMLDocument(pool) {
    var frame = newIFrame(pool);
    return frame.contentWindow.document;
}

function setUp(ctx) {
    ctx.iframes = [];
}

function tearDown(ctx) {
    ctx.iframes.forEach(function (e) {
        e.parentNode.removeChild(e);
    });
}

function unit(f) {
    return function () {
        var ctx = {};
        setUp(ctx);
        try {
            f(ctx);
        } finally {
            tearDown(ctx);
        }
    }
}

// helper method for debugging
function obj_dump(p) {
    for (var p in p) {
        console.log(p + ': ' + o[p] + '; ');
    }

}
